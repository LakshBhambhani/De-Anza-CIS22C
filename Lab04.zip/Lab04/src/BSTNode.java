
public class BSTNode {

	 /* Class containing left
     and right child of current node
	 * and key value*/
     Dollar key;
     BSTNode left, right;

     public BSTNode(Dollar item)
     {
         key = item;
         left = right = null;
     }
 
}
